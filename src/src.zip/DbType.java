/**
 * Created by dan on 06/03/16.
 */
public interface  DbType {
    public Object get();
    public int getSize();
    public String print();
    public void   set(Object val);

}
