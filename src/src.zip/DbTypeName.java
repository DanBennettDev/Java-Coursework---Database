/**
 * Enum for the types available
 */
public enum DbTypeName {
    INT, FLOAT, STRING
}
