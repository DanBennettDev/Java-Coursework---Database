/**
 * DbFile handling for database
 */

import java.io.*;
import java.nio.file.FileSystemException;
import java.util.List;

public class DbFile {

    private final char DELIMITER = 0x0241E;
    private final char ENDRECORD = 0x0000A;
    private final String EXTENSION = ".dbf";

    private String name;
    private String filepath;
    private String folderpath;
    private int lineCounter=0;


    DbFile(String subfolder, String name) {
        this.name = name;
        if(!subfolder.endsWith("/")){
            subfolder = subfolder + "/";
        }
        this.filepath = subfolder + name + EXTENSION;
        this.folderpath = subfolder;
    }

    public String getName(){
        return name;
    }

    private String recordToLine(DbRecord rec) {
        int i = 0;
        String line = fieldStrClean((String)rec.getVal(i));
        i++;

        while (i < rec.size()) {
            line = line + DELIMITER + rec.getVal(i++);
        }
        return line + ENDRECORD;
    }


    private DbRecord lineToRecord(DbTable t, String line){
        String[] fields = line.split(""+DELIMITER, t.getFieldCount());
        DbRecord r = new DbRecord(t.getNextKey(), t.getFields());
        for(int i=0; i< t.getFieldCount(); i++ ){
            r.set(i,fields[i]);
        }
        return r;
    }

    private String fieldStrClean(String field) {
        String clean = field;
        if (clean.contains("" + DELIMITER)) {
            clean = clean.replace("" + DELIMITER, " ");
        }
        if (clean.contains("" + ENDRECORD)) {
            clean = clean.replace("" + ENDRECORD, " ");
        }
        return clean;
    }


    public void readFromFile(DbTable t) {
        t.truncate();
        String readPath = new File("").getAbsolutePath().concat("/"+filepath);
        try {
            InputStreamReader isr = new InputStreamReader(new FileInputStream(readPath));
            BufferedReader fr = new BufferedReader(isr);
            this.lineCounter=0;
            fr.lines().forEach(l -> processFileLines(t, l));

        } catch (FileNotFoundException e){
            System.out.println("Cannot connect to file " + readPath);
        }
    }

    private void processFileLines(DbTable t, String line){
        if(lineCounter++==0){
            makeTable(line, t);
            return;
        }
        t.insertRecord(lineToRecord(t, line));
    }

    // check if table has been set up, if not, set up from header details
    private void makeTable(String line, DbTable t){
        if(t.getFieldCount()>0){
            //table already initialized
            return;
        }
        String[] parts = line.split(""+DELIMITER);
        String[] fieldParts;
        String fieldName;
        DbTypeName type=DbTypeName.STRING;
        int size=0;
        for(int i=0; i< parts.length; i++){
            fieldParts = parts[i].split("\\(");
            fieldName = fieldParts[0];

            if(fieldParts[1].startsWith("STR")){
                type = DbTypeName.STRING;
                size = getStringSizeFromHdr(fieldParts[1]);
            }
            if(fieldParts[1].startsWith("INT")){
                type = DbTypeName.INT;
                size = 0;
            }
            if(fieldParts[1].startsWith("FLT")){
                type = DbTypeName.FLOAT;
                size = 0;
            }

            t.addField(fieldName,type,size);
        }
    }

    private int getStringSizeFromHdr(String part){
        int numEnd = part.length() -1;
        String sizeStr = part.substring(3, numEnd);
        return Integer.parseInt(sizeStr);
    }

    public String getFileExtension(){return EXTENSION;};


    public void writeToFile(DbTable t) throws Exception {
        createFolderIfNotExist(folderpath);
        File f = new File(filepath);
        String data = makeHeader(t.getFields());
        for (int i = 0; i < t.getRowCount(); i++) {
            data = data + recordToLine(t.getRecord(i));
        }
        try {
            if (!f.exists()) {
                f.createNewFile();
            }
            OutputStreamWriter ow = new OutputStreamWriter(new FileOutputStream(f));
            ow.write(data);
            ow.close();
        } catch (FileNotFoundException e) {
            System.out.println("cannot find file ./" + filepath);
            throw e;
        } catch (IOException io) {
            System.out.println("cannot write to file ./" + filepath);
            throw io;
        }
    }

    public void createFolderIfNotExist(String folderPath) throws FileSystemException{
        File dir = new File(folderPath);

        if (!dir.exists()) {
            try{
                boolean mkdir = dir.mkdir();
                if(!mkdir){
                    throw new FileSystemException(folderPath);
                }
            }
            catch(Exception e){
                System.out.println("Could Not Create Folder");
                throw e;
            }
        }
    }

    private String makeHeader(List<DbField> fields){
        String header = "";
        DbField thisfield;
        for(int i=0; i< fields.size(); i++){
            thisfield = fields.get(i);
            header = header + thisfield.getName() + "(";
            switch(thisfield.getType()){
                case STRING:
                    header = header + "STR" + Integer.toString(thisfield.getSize());
                    break;
                case INT:
                    header = header + "INT";
                    break;
                case FLOAT:
                    header = header + "FLT";
                    break;
                default:
                    System.out.println("invalid type in makeheader");
                    throw new IllegalArgumentException();
            }
            header = header + ")" + DELIMITER;
        }
        return header + ENDRECORD;
    }


    public static void tests() {
        Tester t = new Tester();
        System.out.println("Testing: DbFile - internal");
        Boolean check = false;
        char ENDRECORD = 0x0000A;

        DbTable tab = new DbTable("tester");
        tab.addField("f1", DbTypeName.STRING, 30);
        tab.addField("f2", DbTypeName.STRING, 30);
        tab.addField("f3", DbTypeName.STRING, 30);
        tab.addField("f4", DbTypeName.STRING, 30);

        DbRecord r = new DbRecord(tab.getNextKey(), tab.getFields(), "Beef", "cartesian", "3", "Smoggy");
        DbFile f = new DbFile("./", "test");

        t.is(f.recordToLine(r), "Beef␞cartesian␞3␞Smoggy" + ENDRECORD, "recordToLine gives correct output");
        t.is(f.fieldStrClean("Beef␞cartesian␞3␞Smoggy"), "Beef cartesian 3 Smoggy", "fieldStrToCSV cleans delimiters");
        r = f.lineToRecord(tab,"Beef␞cartesian␞3␞Smoggy");
        t.is((String)r.getVal(0), "Beef", "lineToRecord gives correct output0");
        t.is((String)r.getVal(1), "cartesian", "lineToRecord gives correct output1");
        t.is((String)r.getVal(2), "3", "lineToRecord gives correct output2");
        t.is((String)r.getVal(3), "Smoggy", "lineToRecord gives correct output3");

        t.is(f.makeHeader(tab.getFields()),"f1(STR30)␞f2(STR30)␞f3(STR30)␞f4(STR30)␞" + ENDRECORD, "Makes header correctly");

        t.is(f.getStringSizeFromHdr("STR30)"), 30, "reads size from string details");

        t.results();

    }

}



