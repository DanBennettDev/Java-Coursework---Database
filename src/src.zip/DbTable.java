import java.util.ArrayList;
import java.util.List;

/**
 * DbTable class for database
 *
 */


public class DbTable {

    private String name;
    private List<DbField> fields;
    private List<DbRecord> records;
    private int nextKey;

    DbTable(String name){
        this.fields= new ArrayList<>();
        this.name = name;
        this.records = new ArrayList<>();
        this.nextKey = 0;
    }

    public void addField(String name, DbTypeName type, int size){
        if(getFieldNameExists(name)){
            throw new IllegalArgumentException();
        }
        if(getRowCount()>0){
            System.out.println("can't add extra fields to Table with records");
            throw new IllegalArgumentException();
        }
        DbField f = new DbField(name, type, size);
        fields.add(f);
    }

    public void addField(String name, DbTypeName type){
        addField(name, type, 0);
    }

    public boolean getFieldNameExists(String name){
        for(int i=0 ; i<getFieldCount(); i++){
            if(getFieldName(i).equals(name)){
                return true;
            }
        }
        return false;
    };


    // returns table name
    public int getNextKey(){
        return nextKey++;
    }

    public String getName(){
        return name;
    }

    // returns number of records in table
    public int getRowCount(){
        return this.records.size();
    }

    // returns number of fields in table
    public int getFieldCount(){
        return this.fields.size();
    }

    // returns List of fieldnames
    public List<String> getFieldNames(){
        List<String> out = new ArrayList<>();
        for(int i=0; i<this.fields.size(); i++){
            out.add(fields.get(i).getName());
        }
        return out;
    }

    // returns List of fieldtypes
    public List<DbTypeName> getFieldTypes(){
        List<DbTypeName> out = new ArrayList<>();
        for(int i=0; i<this.fields.size(); i++){
            out.add(fields.get(i).getType());
        }
        return out;
    }

    // returns List of field sizes
    public List<Integer> getFieldSizes(){
        List<Integer> out = new ArrayList<>();
        for(int i=0; i<this.fields.size(); i++){
            out.add(fields.get(i).getSize());
        }
        return out;
    }

    public List<DbField> getFields(){
        return fields;
    }

    // get name of numbered field. Throws exception if fieldNo does not exist in table
    public String getFieldName(int fieldNo) {
        if(fieldNo>=this.fields.size() || fieldNo<0) {
            throw new IndexOutOfBoundsException();
        }
        return fields.get(fieldNo).getName();
    }

    // get type of numbered field. Throws exception if fieldNo does not exist in table
    public DbTypeName getFieldType(int fieldNo) {
        if(fieldNo>=this.fields.size() || fieldNo<0) {
            throw new IndexOutOfBoundsException();
        }
        return fields.get(fieldNo).getType();
    }

    // get size of numbered field. Throws exception if fieldNo does not exist in table
    public int getFieldSize(int fieldNo) {
        if(fieldNo>=this.fields.size() || fieldNo<0) {
            throw new IndexOutOfBoundsException();
        }
        return fields.get(fieldNo).getSize();
    }


    // get number of named field.
    public int getFieldNo(String name){
        for(int i=0; i< this.fields.size(); i++){
            if(fields.get(i).getName().equals(name)){
                return i;
            }
        }
        throw new IllegalArgumentException();
    }

    // set numbered field to new name, disallows duplication of names
    public void setFieldName(int i, String name){
        if(i>fields.size()||i<0){
            throw new IllegalArgumentException();
        }
        for(DbField item : fields){
            if(item.getName().equals(name)){
                throw new IllegalArgumentException();
            }
        }
        fields.get(i).setName(name);
    }

    // set given field name to new name, disallows duplication of names
    public void setFieldName(String fieldName, String newName) {
        if(fieldName.equals(newName)){return; }
        int i=0, size=this.fields.size();
        while(!fields.get(i).getName().equals(fieldName)){
            i++;
            if(i==size){
                throw new IllegalArgumentException();
            }
        }
        setFieldName(i, newName);

    }

    public void insertRecord(String ... values){
        if(values.length < this.fields.size()){
            throw new IllegalArgumentException();
        }
        DbRecord rec = new DbRecord(getNextKey(), fields, values);
        this.records.add(rec);
    }

    public void insertRecord(DbRecord r){
        if(r.size()==this.getFieldCount()){
            this.records.add(r);
        } else {
            throw new IllegalArgumentException();
        }
    }


    private int getKeyRow(int key){
        if(key>=nextKey || key <0){
            return -1;
        }
        int left=0, right=this.records.size()-1, mid = ((right-left)/2)+left;
        int val;
        while ( (val=this.records.get(mid).getKey()) != key && left < right) {
            if(val < key) {left=mid+1;}
            if(val > key) {right=mid-1;}
            mid = ((right-left)/2)+left;
        }
        if(val!=key){
            return -1;
        }
        return mid;
    }


    public void deleteRecord(int key){
        int row = getKeyRow(key);
        if(row>=0 && row < this.records.size()){
            this.records.remove(row);
            return;
        }
        System.out.println("not found");
        return;
    }

    public void truncate(){
        for(int i=0; i<getRowCount(); i++){
            deleteRecord(i);
        }
        this.nextKey=0;
    }

    public DbRecord getRecord(int key){
        int row = getKeyRow(key);
        if(row<records.size() && row>=0){
            return records.get(row);
        }
        throw new IllegalArgumentException();
    }

    public Object getValue(int key, String field){
        int fieldNo = getFieldNo(field);
        return getValue(key, fieldNo);
    }

    public Object getValue(int key, int fieldNo){
        int row = getKeyRow(key);
        if (fieldNo != -1 && row<records.size() && row >= 0) {
            return records.get(row).getVal(fieldNo);
        }
        return null;
    }

    public static void tests() {
        Tester t = new Tester();
        Boolean check = false;
        System.out.println("Testing: DbTable - internal tests");

        //init
        DbTable tab = new DbTable("animals");
        tab.addField("name", DbTypeName.STRING, 30);
        tab.addField("size", DbTypeName.STRING, 30);
        tab.addField("fierceness", DbTypeName.STRING, 30);

        tab.insertRecord("giraffe", "large", "moderate");
        tab.insertRecord("angry gopher", "small", "moderate");
        tab.insertRecord("calm gopher", "small", "negligible");
        tab.insertRecord("penguin", "smallish", "zero");

        t.is(tab.records.get(0).getKey(), 0, "check keys applied correctly 1");
        t.is(tab.records.get(1).getKey(), 1, "check keys applied correctly 2");
        t.is(tab.records.get(2).getKey(), 2, "check keys applied correctly 3");
        t.is(tab.records.get(3).getKey(), 3, "check keys applied correctly 4");

        t.is(tab.getKeyRow(0), 0, "check getKeyRow returns right row for first key");
        t.is(tab.getKeyRow(1), 1, "check getKeyRow returns right row for key 1");
        t.is(tab.getKeyRow(2), 2, "check getKeyRow returns right row for key 2");
        t.is(tab.getKeyRow(3), 3, "check getKeyRow returns right row for key 3");

        tab.records.remove(1);
        System.out.println(tab.nextKey);

        t.is(tab.getKeyRow(1), -1, "check getKeyRow returns right row for key 1 after removal");
        t.is(tab.getKeyRow(2), 1, "check getKeyRow returns right row for last key after removal");
        t.is(tab.getKeyRow(3), 2, "check getKeyRow returns right row for first key after removal");
        t.is(tab.getKeyRow(0), 0, "check getKeyRow returns right row for last key after removal");


        t.results();
    }
}









