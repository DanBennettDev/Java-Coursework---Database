/**
 * Tests for DbPrint Class
 */
public class DbPrintTest {

    public static void run() {
        System.out.println("Testing: DbPrint");

        DbPrint.tests();


    }


    public static void main(String[] args) {
        run();
    }
}
