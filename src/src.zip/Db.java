import java.io.File;
import java.io.FilenameFilter;
import java.nio.file.FileSystemException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dan on 12/03/16.
 */

public class Db {


    private String name;
    private String dbFolder;
    private List<DbTable> tables;
    private List<DbFile> dbFiles;
    private DbFile fileInfo;

    Db(String name, String dbFolder){
        this.name = name;
        this.dbFolder = dbFolder;
        this.tables = new ArrayList<>();
        this.dbFiles = new ArrayList<>();

        this.fileInfo = new DbFile("", "");
        try {
            fileInfo.createFolderIfNotExist(this.dbFolder);
        } catch(FileSystemException e) {
            System.exit(1);
        }
        scanForDbs();

    }

    public void printFiles(){
        for(int i=0; i<dbFiles.size(); i++){
            System.out.print(dbFiles.get(i).getName() + ", ");
        }
        System.out.print("\n");
    }

    // scan folder for database files and set up dbFiles
    private void scanForDbs(){
        File dir = new File(dbFolder);
        DbFile thisDbF;
        String ext = this.fileInfo.getFileExtension();
        if(!dir.exists()) {
            System.out.println("no directory "+ this.dbFolder);
            throw new IllegalArgumentException();
        }

        FilenameFilter filter = new FilenameFilter() {
            public boolean accept(File dir, String filename) {
                return filename.endsWith(ext);
            } };

        File[] files = dir.listFiles(filter);

        for(File f: files){
            thisDbF = new DbFile(dbFolder, f.getName().replace(ext, ""));
            dbFiles.add(thisDbF);
        }
    }

    public DbTable getTable(String name){
        DbTable tab;
        for(int i=0; i<this.tables.size(); i++) {
            tab=this.tables.get(i);
            if(tab.getName().equals(name)) {
                return tab;
            }
        }
        return null;
    }

    public int getTableCount(){return this.tables.size();};
    public int getFileCount(){return this.dbFiles.size();}




    public void saveTable(String name) throws Exception{
        DbTable tab = getTable(name);
        if(tab==null){
            System.out.println("no such table");
            throw new IllegalArgumentException();
        }
        DbFile file = getFile(name, true);
        try {
            file.writeToFile(tab);
            return;
        } catch(Exception e) {
            System.out.println("failed to save db " +name);
            throw e;
        }
    }

    public void saveAllTables(){
        for(int i=0; i<tables.size(); i++){
            try {
                saveTable(tables.get(i).getName());
            } catch (Exception e){

            }
        }
    }

    public void loadAllTables(){
        for(int i=0; i<dbFiles.size(); i++){
            loadTable(dbFiles.get(i).getName());
        }
    }


    public void loadTable(String name){
        DbFile file = getFile(name, false);
        if(file==null){
            System.out.println("no such file, "+name+" cannot load table");
        }
        DbTable tab = getTable(name);
        if(tab==null){
            tab = new DbTable(name);
            this.tables.add(tab);
        }
        file.readFromFile(tab);

    }



    private DbFile getFile(String name, boolean createIfNotFound){
        for(int i=0; i<this.dbFiles.size(); i++){
            if(this.dbFiles.get(i).getName().equals(name)){
                return this.dbFiles.get(i);
            }
        }
        if(createIfNotFound) {
            DbFile newFile = new DbFile(dbFolder, name);
            this.dbFiles.add(newFile);
            return newFile;
        }
        return null;
    }



    public void AddTable(String name){
        DbTable t = new DbTable(name);
        tables.add(t);
    };


    public static void test(){
        Tester t = new Tester();
        Boolean check = false;
        System.out.println("Testing: Records Internal");

        //delete subfolder in case of rerunning tests

        Db testDb = new Db("testDB", "testDB");

        testDb.scanForDbs();

        t.is(testDb.dbFiles.size(),0,"initialising class - no dbfiles at first to load from");

        testDb.AddTable("DbTest");

        t.is(testDb.tables.size(),1, "add table successfully");

        testDb.tables.get(0).addField("String", DbTypeName.STRING, 30);
        testDb.tables.get(0).addField("Int", DbTypeName.INT);
        testDb.tables.get(0).addField("Float", DbTypeName.FLOAT);
        testDb.tables.get(0).addField("String2", DbTypeName.STRING, 30);

        testDb.tables.get(0).insertRecord("Row1","3", "3.3", "Cartouche");
        testDb.tables.get(0).insertRecord("Row2","4", "4.4", "Spizzle");
        testDb.tables.get(0).insertRecord("Row3","5", "-1.2", "Refried");
        testDb.tables.get(0).insertRecord("Row4","6", "6.6", "Klepto");



        t.results();
    }

}
